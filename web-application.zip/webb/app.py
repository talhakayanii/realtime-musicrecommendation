import csv
import os
from flask import Flask, render_template, request
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from pymongo import MongoClient

app = Flask(__name__)

# Connect to MongoDB
client = MongoClient('localhost', 27017)
db = client['music_db']
collection = db['audio_features']

# Path to the CSV file
csv_filename = 'suggested.csv'

# Function to apply the model
def apply_model(clicked_song_id):
    # Query MongoDB for the MFCC features of the clicked song
    query_track_mfcc = np.array(collection.find_one({'track_id': clicked_song_id})['mfcc'][0]).reshape(1, -1)
    
    # Find similar tracks using cosine similarity
    similar_tracks = []
    cursor = collection.find({})
    for document in cursor:
        track_id = document['track_id']
        track_mfcc = np.array(document['mfcc'][0]).reshape(1, -1)
        similarity = cosine_similarity(query_track_mfcc, track_mfcc)[0][0]
        if similarity > 0.5 and track_id != clicked_song_id:
            similar_tracks.append(str(track_id))
    
    print(f"Similar tracks found for {clicked_song_id}: {similar_tracks}")
    
    # Store the similar tracks in a CSV file
    with open(csv_filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['Clicked Song ID', 'Similar Tracks'])
        writer.writerow([clicked_song_id, ', '.join(similar_tracks)])
        file.flush()

    return 'Model applied successfully'

@app.route('/')
def home():
    return render_template('spotify.html')

@app.route('/search')
def search():
    return render_template('page1.html')

@app.route('/history')
def history():
    return render_template('page2.html')

@app.route('/suggested')
def suggested():
    # Read the CSV file and extract the "Similar Tracks" column
    with open(csv_filename, mode='r') as file:
        csv_reader = csv.DictReader(file)
        # Read the second row (data row)
        row = next(csv_reader)
        # Extract the "Similar Tracks" column from the second row
        similar_tracks = row['Similar Tracks'].split(', ')

    return render_template('page3.html', similar_tracks=similar_tracks)

@app.route('/apply_model', methods=['POST'])
def apply_model_route():
    # Retrieve the clicked song from the AJAX request
    data = request.get_json()
    clicked_song_id = int(data['clickedSong'].split('.')[0])

    result = apply_model(clicked_song_id)

    return result, 200

if __name__ == '__main__':
    app.run(debug=True)
